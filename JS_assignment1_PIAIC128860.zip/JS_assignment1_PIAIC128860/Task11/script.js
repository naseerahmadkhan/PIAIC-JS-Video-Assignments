var celsius=25;
var fahrenheit =70;

var c2f = (fahrenheit -32)*5/9;
var f2c = (celsius *9/5)+32;



document.writeln(celsius+" <sup>o</sup>C "+" is "+f2c+" <sup>o</sup>F");
document.writeln('<br>');
document.writeln(fahrenheit+" <sup>o</sup>C "+" is "+c2f+" <sup>o</sup>F");
