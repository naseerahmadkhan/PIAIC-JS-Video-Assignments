var num;
document.writeln("Value after variable declaration is: "+num);

num = 5;
document.writeln("<br>");
document.writeln("Initial Value is: "+num);

++num;
document.writeln("<br>");
document.writeln("Value after increment is "+num);

num+=7;
document.writeln("<br>");
document.writeln("Value after addition is "+num);

--num;
document.writeln("<br>");
document.writeln("Value after decrement is "+num);

num%=3;
document.writeln("<br>");
document.writeln("The remainder is "+num);