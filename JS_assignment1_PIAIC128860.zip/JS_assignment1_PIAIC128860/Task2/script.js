var stdName = "Jhone Doe";
var stdAge = 15 + " years old";
var course = "Certified Mobile Application Development";
alert(stdName);
alert(stdAge);
alert(course);