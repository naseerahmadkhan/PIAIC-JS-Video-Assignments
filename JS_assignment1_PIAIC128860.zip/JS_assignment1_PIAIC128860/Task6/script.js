var birthYear = 1990;
document.writeln("My birth year is "+birthYear);
document.write("<br>");
document.writeln("Datatype of declared variable is number");