var a= 10;
var b = 2;


document.writeln("Subtraction: "+ a +" - " +b+" is = "+ (a-b) );
document.write("<br>")
document.writeln("Multiplication: "+ a +" * " +b+" is = "+ (a*b) );
document.write("<br>")
document.writeln("Division: "+ a +" / " +b+" is = "+ (a/b) );
document.write("<br>")
document.writeln("Division: "+ a +" % " +b+" is = "+ (a%b) );