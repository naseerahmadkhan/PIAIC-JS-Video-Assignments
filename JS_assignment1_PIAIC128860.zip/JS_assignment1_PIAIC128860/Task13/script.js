var a = 10;


document.write("Result:");
document.write("<br>");
document.writeln("The value of a is: "+a);
document.write("<br>");
document.write(".................................");



document.write("<br><br>");
document.writeln("The value of ++a is: "+ ++a);
document.write("<br>");
document.writeln("Now the value of a is: "+ a);


document.write("<br><br>");
document.writeln("The value of a++ is: "+ a++);
document.write("<br>");
document.writeln("Now the value of a is: "+ a);


document.write("<br><br>");
document.writeln("The value of --a is: "+ --a);
document.write("<br>");
document.writeln("Now the value of a is: "+ a);


document.write("<br><br>");
document.writeln("The value of a-- is: "+ a--);
document.write("<br>");
document.writeln("Now the value of a is: "+ a);