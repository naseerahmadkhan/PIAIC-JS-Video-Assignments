var age = 15;
alert("i am "+age+" years old!")