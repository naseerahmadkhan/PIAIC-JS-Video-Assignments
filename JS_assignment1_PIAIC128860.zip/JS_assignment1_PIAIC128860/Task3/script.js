var email = "example@example.com";
alert("My email address is "+email);