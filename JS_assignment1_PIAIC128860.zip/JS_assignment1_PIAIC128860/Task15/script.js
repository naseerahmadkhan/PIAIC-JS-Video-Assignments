var a = 2, b = 1;
var result = --a - --b + ++b + b--;

// Fist uniary operators will be evaluated e.g. ++a,b--

// --a will decrement a with 1 first and use the value                ==> a=1  
// --b will be evaluated, it will first decrement and use the value   ==> b=0

//   1 - 0 = 1

// ++b will be evaluated, it will first increment and use the value   ==> b=1
// b-- will be evaluated again and it will use value first and then decrement the value ==> b=1

// 1 + (1 + 1)




document.writeln(result);