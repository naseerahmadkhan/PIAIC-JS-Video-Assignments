var usd=10;
var sar=25;
var pkr=(usd*155)+(sar*41);




document.writeln("Total Currency in PKR"+pkr);

