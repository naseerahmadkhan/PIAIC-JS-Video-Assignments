
document.writeln("<h1>Rules for naming JS variables</h1>");
document.writeln("Variable names can only contain, numbers, $ and _. For example : $my_1stVariable ");
document.writeln("<br>");
document.writeln("Variable must begin with a letter, $ or _ . For example:  $name, _name or name")
document.writeln("<br>");
document.writeln("Variable names are case sensitive ")
document.writeln("<br>");
document.writeln("Variable names should not be JS keywords");
