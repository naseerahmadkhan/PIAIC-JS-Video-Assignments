var a= 3;
var b = 5;
var sum = a+b;

document.writeln("Sum of "+a+" and "+b+" is "+sum);
