var number = prompt("Enter Number to check whether it is Positive, Negative or Zero");
number = Number(number);

if(number >0){
  alert("Number is Positive");
}else if(number <0){
  alert("Number is Negative");
}else if(number === 0){
  alert("Number is Zero");
}else if(isNaN(number)){
  alert("Invalid number");
}