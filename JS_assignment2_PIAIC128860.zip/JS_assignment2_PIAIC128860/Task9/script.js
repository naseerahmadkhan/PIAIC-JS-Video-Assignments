var vowel = prompt("Enter char to check vowel");
vowel = vowel.toLowerCase();
console.log(vowel)
if((vowel=='a' || vowel=='e' || vowel=='i' || vowel=='o'|| vowel=='u')){
  alert("Its vowel")
}else{
  alert("false");
}