var result;

var num1 = prompt("Enter first number");
var op = prompt("Enter  operation e.g. + - / * %");
var num2 = prompt("Enter second number");

num1 = Number(num1);
num2 = Number(num2);

if(!isNaN(num1) && !isNaN(num2)){
  Calc(op);
  

}else{
  alert("You type invalid number");
  Calc(op);
}

function Calc(op){
  switch(op){
    case '+':
      result = num1+num2;
      alert("Ans: "+result);
      
      break;
  
      case '-':
        result = num1-num2;
        alert("Ans: "+result);
        break;
        case '*':
        result = num1*num2;
        alert("Ans: "+result);
        break;
  
        case '/':
        result = num1/num2;
        alert("Ans: "+result);
        break;
  
        case '%':
        result = num1%num2;
        alert("Ans: "+result);
        break;
  
        default:
        alert("Wrong operator choosed");
        break;
  }
}