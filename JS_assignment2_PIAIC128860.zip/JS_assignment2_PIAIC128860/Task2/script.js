var ans = prompt("Enter Signal Color");
ans = ans.toLowerCase();
switch (ans) {
  case "red":
    alert("Must Stop");
    break;

  case "yellow":
    alert("Ready to move");
    break;

  case "green":
    alert("move now");
    break;
  default:
    alert("wrong signal color");
    break;
}
