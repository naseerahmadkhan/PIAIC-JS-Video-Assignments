var secretNum = 10
var ans=0;

while(ans != secretNum){
  ans = prompt("Guess Secret Number from 1 to 10");
  ans = parseInt(ans);
  if(ans+1 == secretNum){
    alert("Close enough to the correct answer");
  }else if(ans == secretNum){
    alert("Bingo! Correct answer")
  }else{
    alert("Sorry! Wrong guess...Try again!")
  }

}