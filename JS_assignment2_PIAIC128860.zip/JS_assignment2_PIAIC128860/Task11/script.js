var time = prompt("Enter time in 24hours format e.g. 1900");

var lastTwoDigit = time.substr(time.length - 2);
lastTwoDigit =parseInt(lastTwoDigit);

if(lastTwoDigit >=00 && lastTwoDigit <=59){
    time = parseInt(time);
    if(time >=0000 && time <1200){
        alert("Good Morning");
    }else if(time >= 1200 && time < 1700){
        alert("Good After Noon!");
    }else if(time >= 1700 && time < 2100){
        alert("Good After Evening!");
    }else if(time >= 2100 && time <= 2359){
        alert("Good Night!");
    }else{
        alert("invlid format");
    }
}else{
    alert("invlid range! this should be e.g. 1900 - 1959");
}








