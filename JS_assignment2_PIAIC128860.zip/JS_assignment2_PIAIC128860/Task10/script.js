var password="piaic";
var f_pass = prompt("Please Enter you password");
var c_pass = prompt("Please Re-Enter you password");

((f_pass == c_pass)) ?(Auth(c_pass,password)):(alert("Invalid Password"));


function Auth(c,p){
if(c === p)
alert("Correct")
else
alert("Invalid Password")
}