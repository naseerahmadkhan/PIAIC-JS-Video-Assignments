var defaultCity=""
var ans = prompt("Enter city name",defaultCity);
if(ans =="karachi"){
    alert("Welcome to city of lights")
}else{
    alert("Welcome to the page");
}