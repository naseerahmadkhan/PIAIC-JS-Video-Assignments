var number; 
number = prompt("Enter number to check whether it is \n\nEven or Odd, \n\nTo Cancel press 'c'");
while(number !='c'){
  
  number = parseInt(number);
  if(number %2 == 0){
    alert(number+" is even");
    number = prompt("Enter number to check whether it is \n\nEven or Odd, \n\nTo Cancel press 'c'");
  }else if(isNaN(number)){
    alert("You entered invalid number");
    number = prompt("Enter number to check whether it is \n\nEven or Odd, \n\nTo Cancel press 'c'");
  }else if(number %2 != 0){
    alert(number+" is odd");
    number = prompt("Enter number to check whether it is \n\nEven or Odd, \n\nTo Cancel press 'c'");
  }
}