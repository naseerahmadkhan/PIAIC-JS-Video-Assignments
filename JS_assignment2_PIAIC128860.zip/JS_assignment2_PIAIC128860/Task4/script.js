// Task4

var sub1Marks = prompt("Enter of Subject 1 marks");
var sub2Marks = prompt("Enter of Subject 2 marks");
var sub3Marks = prompt("Enter of Subject 3 marks");

sub1Marks = parseInt(sub1Marks);
sub2Marks = parseInt(sub2Marks);
sub3Marks = parseInt(sub3Marks);

var marksObtained = sub1Marks + sub2Marks + sub3Marks;
var pctageObtained = ((marksObtained / 300) * 100).toFixed(2);

document.writeln("Total Marks: " + 300);
document.write("<br>");
document.writeln("Marks Otained: " + marksObtained);
document.write("<br>");
document.writeln("Percentage Obtained: " + pctageObtained + " %");
document.write("<br>");
// document.writeln("Grade: "+Grade(pctageObtained)[0]);
// document.write("<br>");
// document.writeln("Remarks: "+Grade(pctageObtained)[1]);
document.writeln("Grade: " + Grade(pctageObtained).grade);
document.write("<br>");
document.writeln("Remarks: " + Grade(pctageObtained).remarks);

function Grade(pctageObtained) {
  var result = {
    grade: "",
    remarks: "",
  };
  if (pctageObtained >= 80) {
    result = {
      grade: "A-one",
      remarks: "Excelent",
    };
    return result;
  } else if (pctageObtained >= 70 && pctageObtained <= 79) {
    result = {
      grade: "A",
      remarks: "Good",
    };
    return result;
  } else if (pctageObtained >= 60 && pctageObtained <= 69) {
    result = {
      grade: "B",
      remarks: "You need to improve",
    };
    return result;
  } else {
    result = {
      grade: "Fail",
      remarks: "Sorry",
    };
    return result;
  }
}
